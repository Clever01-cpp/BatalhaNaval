from src import constants
import pygame
from pygame.locals import *


def criar_matriz():
    linhas = 10 
    colunas = 10
    matriz = []
    for i in range(linhas):
        linha_percorrida = []
        for j in range(colunas):
            linha_percorrida.append(0)
        matriz.append(linha_percorrida)
    return matriz
def desenhar_matriz(screen, matriz):
    for linha in range(len(matriz)):
        for coluna in range(len(matriz[0])):
            x = constants.OFFSET_X + ((coluna * constants.TAMANHO_CELULA))
            y = constants.OFFSET_Y + (linha * constants.TAMANHO_CELULA) 

            estado = matriz[linha][coluna]

            if estado == 0:
                cor = constants.AZUL_MARINHO
            elif estado == 1:
                cor = constants.AZUL_CLARO
            
            pygame.draw.rect(screen,cor,(x,y, constants.TAMANHO_CELULA, constants.TAMANHO_CELULA))
            pygame.draw.rect(screen, constants.PRETO, (x, y, constants.TAMANHO_CELULA, constants.TAMANHO_CELULA), 1)
def posição_celula(pos_x, pos_y,):
    if (constants.OFFSET_X <= pos_x <= (constants.OFFSET_X + (constants.TAMANHO_CELULA * 10)) and 
        constants.OFFSET_Y <= pos_y <= (constants.OFFSET_Y + (constants.TAMANHO_CELULA * 10))):
        coluna = ((pos_x - constants.OFFSET_X)) // constants.TAMANHO_CELULA
        linha = (pos_y - constants.OFFSET_Y) // constants.TAMANHO_CELULA
        return int(linha), int(coluna)
    else:
        return None, None
def processar_clique(linha, coluna, matriz):
    if linha is None:
        return
    
    estado_atual = matriz[linha][coluna]

    if estado_atual == 0:
        matriz[linha][coluna] = 1
    elif estado_atual == 1:
        matriz[linha][coluna] = 0