import pygame
from pygame.locals import *
from src import constants
from src import functions
from sys import exit

def main():
    pygame.init()

    screen = pygame.display.set_mode((constants.LARGURA_TELA, constants.ALTURA_TELA))
    pygame.display.set_caption("Batalha naval !")
    clock = pygame.time.Clock()
    
    matriz = functions.criar_matriz()
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                x,y = pygame.mouse.get_pos()
                linha, coluna = functions.posição_celula(x,y)
                functions.processar_clique(linha, coluna, matriz)
                
        screen.fill(constants.BRANCO)
        
        
        
        functions.desenhar_matriz(screen, matriz)
       
      






        pygame.display.update()






if __name__ == "__main__":
    main()
    